import xbmc, xbmcgui
import os, sys, thread, time

command = "System.Exec(~/moonlight/moonlight.sh)"
xbmc.executebuiltin(command) 
